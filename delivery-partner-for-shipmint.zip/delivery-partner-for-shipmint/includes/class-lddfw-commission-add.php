<?php
class LDDFW_Paycomm {
				
	public function screen_paycomm() {

		echo '<div class="wrap">
		<h1 class="wp-heading-inline">' . esc_html( __( 'Pay Commission', 'lddfw' ) ) . '</h1>
		  ' . LDDFW_Admin::lddfw_admin_plugin_bar() . '
		  <hr class="wp-header-end">';
		  echo '</div>';
	
		ob_start(); 
	  
    include_once plugin_dir_path( dirname( __FILE__ ) ). 'admin/partials/commission-add.php';
		   
		$template = ob_get_contents(); 

		ob_end_clean(); 

		echo $template;

	}

}