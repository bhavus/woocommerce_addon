<?php



class LDDFW_Paylist {
	
	public function screen_paylist() {

		echo '<div class="wrap">
		<h1 class="wp-heading-inline">' . esc_html( __( 'Paid Commission List', 'lddfw' ) ) . '</h1>
		  ' . LDDFW_Admin::lddfw_admin_plugin_bar() . '
		  <hr class="wp-header-end">';
		  echo '</div>';

	    //global $wpdb, $wp_roles;

	    ob_start(); // started buffer
       
       include_once plugin_dir_path( dirname( __FILE__ ) ). 'admin/partials/commission-list.php';
	   
	   $template = ob_get_contents(); // reading content

		ob_end_clean(); // closing and cleaning buffer

		echo $template;

	}

}//class end