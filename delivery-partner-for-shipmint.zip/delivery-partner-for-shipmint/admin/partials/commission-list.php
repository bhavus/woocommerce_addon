<div class="container">
<div class="row" style="margin-top:20px;">
    <div class="col-sm-12">
<div class="panel panel-default">
    <div class="panel-heading wpspp-lib-bg">All Commission List</div>
    <!-- <button class="btn btn-info pull-right" id="btn-first-ajax" style="margin-top:-38px;">First Ajax Request</button> -->
    <div class="panel-body">
        <table id="example_spp" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Total Commission</th>
                    <th>Pay Commission</th>
                    <th>Available Commission</th>
                    <th>Pay By</th>
                    <th>Referance Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="commission-table-list">
                <?php

global $wpdb;
$all_commission = $wpdb->get_results($wpdb->prepare("SELECT * from {$wpdb->prefix}lddfw_commission"), ARRAY_A);

if (count($all_commission) > 0) {
    $i = 1;
    foreach ($all_commission as $index => $data) {
        
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $data['name']; ?></td>
            <td><?php echo $data['total_commission']; ?></td>
            <td><?php echo $data['pay_commission']; ?></td>
            <td><?php echo $data['avil_commission']; ?></td>
            <td><?php echo $data['pay_by']; ?></td>
            <td><?php echo $data['referance_no']; ?></td>
            <td>
                <a href="admin.php?page=lddfw-paycomm" class="btn btn-info wpspp-lib-btn btn-sm" id="create-pay-comm-ajax" data-id="<?php echo $data['id']; ?>"><span class="dashicons dashicons-insert"></span></a>

                <a href="Javascript:;" class="btn btn-info wpspp-lib-btn btn-sm" data-toggle="modal" data-target="#commission-edit-modal" data-id="<?php echo $data['id']; ?>"><span class="dashicons dashicons-edit"></span></a>

                 <a href="Javascript:;" data-toggle="modal" data-target="#wpowt-branch-modal" class="btn btn-info pull-right wpspp-lib-btn btn-sm">Add Department</a>

                <a href="javascipt:void()" class="btn btn-danger wpspp-lib-btn btn-sm cust-plugin-delete" data-id="<?php echo $data['id']; ?>"><span class="dashicons dashicons-trash"></span></a>
              
            </td>
        </tr>
        <?php
    }
} else {
    echo "<h4>No Commission found</h4>";
}
                
                ?>
            </tbody>
            <tfoot>
         
        </tfoot>
        </table>
    </div>
</div>
</div>
</div>
</div>

<!-- Modal -->
<div id="commission-edit-modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <form action="Javascript:Void(0)" id="wpowt-frm-add-frm" method="post">
                    <div class="form-group">
                        <label for="txtbranch">Title</label>
                        <input type="text" required="" class="form-control" placeholder="Enter Department Title" id="wpowt-branch" name="wpowt_branch">
                    </div>
                    <button type="submit" class="btn btn-primary wpowt-lib-btn"><i class="mdi mdi-check-outline"></i> Submit</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<div id="wpowt-branch-modal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Department</h4>
            </div>
            <div class="modal-body">
                <form action="Javascript:Void(0)" id="wpowt-frm-add-frm" method="post">
                    <div class="form-group">
                        <label for="txtbranch">Title</label>
                        <input type="text" required="" class="form-control" placeholder="Enter Department Title" id="wpowt-branch" name="wpowt_branch">
                    </div>
                    <button type="submit" class="btn btn-primary wpowt-lib-btn"><i class="mdi mdi-check-outline"></i> Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>