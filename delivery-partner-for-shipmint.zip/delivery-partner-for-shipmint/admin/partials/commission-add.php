 <script type="text/javascript">
    
   function get_data()
   {
        
                
        let partner_tot_comm = jQuery("#dd_partner_name :selected").attr("data-commission");
       
        //jQuery("#delivery_name_id").val(deliveryid);

        jQuery("#total_commission").val(partner_tot_comm);

        var pay_comm = jQuery("#pay_commission").val();
        
        var rem_comm = partner_tot_comm - pay_comm;
       
        jQuery("#avail_comm").val(rem_comm);

        let partner_name1 = jQuery("#dd_partner_name :selected").text();
        jQuery("#partner_name").val(partner_name1);
   }
 </script>

 <?php
 global $wpdb;
 $query = "SELECT driver_id,user_login,sum(driver_commission) FROM {$wpdb->prefix}users INNER JOIN {$wpdb->prefix}usermeta ON {$wpdb->prefix}users.id = {$wpdb->prefix}usermeta.user_id right JOIN {$wpdb->prefix}lddfw_orders ON {$wpdb->prefix}lddfw_orders.driver_id={$wpdb->prefix}users.id where {$wpdb->prefix}usermeta.meta_key='lddfw_driver_account' GROUP BY {$wpdb->prefix}lddfw_orders.driver_id DESC";  

        $data = $wpdb->get_results($query,ARRAY_A);
       
        $d_name = array();
        $d_name = ' <select id="dd_partner_name" name="dd_partner_name" onchange="get_data()" class="form-control">';
        $d_name .= ' <option value="">Select Partner</option>';
       
        foreach($data as $key => $value)
        {
             $d_name .=  "<option data-commission=".$value['sum(driver_commission)']."  value=".$value['driver_id'].">".$value['user_login']."</option>";

        }
        $d_name .='</select>';
        
    ?>
        
    <div class="container">
        <div class="panel panel-default">
           <div class="panel-heading wpspp-lib-bg">Pay Commission
             <a href="admin.php?page=lddfw-paylist" class="pull-right btn wp-back-btn"><span class="dashicons dashicons-controls-back"></span> Back</a>
           </div>
           <div class="panel-body">
    
        <form method="post" name="frmpost" id="frmpost" >
            <div class="form-group">
               <label for="delivery_name">Delivery Partner Name:</label>
               <input type="hidden"  value="<?php echo $value['driver_id']; ?>" id="delivery_name_id">
                <?php echo $d_name; ?>
            </div>
           <input type="hidden" name="partner_name" id="partner_name">
           <div class="form-group">
               <label for="total_commission">Total Commission:</label>
               <input type="text" class="form-control" name="total_commission" id="total_commission" placeholder="Total Commission">
              
           </div>


           <div class="form-group">
               <label for="pay_commission">Pay Commission:</label>
               <input type="number" class="form-control" name="pay_commission" id="pay_commission" placeholder="Pay Commission" onchange="get_data()" required>
           </div>

           <div class="form-group">
               <label for="avail_comm">Availabel Commission:</label>
               <input type="text" class="form-control"  name="avail_comm" id="avail_comm" placeholder="Available Commission">
           </div>

           <div class="form-group">
               <label for="pay_by">Pay By:</label>
            
              <select class="form-control" id="pay_by" name="pay_by" >
                  <option value="Cash">Cash</option>
                  <option value="Check">Check</option>
                  <option value="Bank">Bank</option>
                  
              </select>
           </div>
      
           <div class="form-group">
               <label for="ref_no">Referance Number:</label>
               <input type="number" class="form-control" name="ref_no" id="ref_no" placeholder="Referance Number" required>
           </div>

          <button type="submit" class="btn btn-info wpspp-lib-btn">Submit</button>
        </form >

                   </div>
            </div>
            </div>