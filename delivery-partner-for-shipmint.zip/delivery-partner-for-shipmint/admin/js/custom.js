
jQuery(document).ready(function () {
   jQuery('#example_spp').DataTable();
    
    //edit record
    jQuery(".cust-plugin-edit").on("click",function(){
            
            var dataid = jQuery(this).attr("data-id");
            var postdata = "action=admin_ajax_request&param=edit_commission&id=" + dataid;
            console.log(postdata);
            jQuery.post(ajaxurl, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                if (data.status == 1) {
                    jQuery("#commission-edit-modal").html(data.template);
                    alert(data.message);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                }else{
                    alert(data.msg);
                }
            });
        
    });

   //insert record
    jQuery("#frmpost").validate({
      
        submitHandler: function(){
              event.preventDefault();   
            var postdata = jQuery("#frmpost").serialize();
         //console.log(postdata);
            //var dname = jQuery("#dd_driver_name :selected").text();

           // postdata += "&action=admin_ajax_request&param=add_commission&dname="+dname;
            
            postdata += "&action=admin_ajax_request&param=add_commission";
            
            jQuery.post(ajaxurl, postdata, function(response){

                var data = jQuery.parseJSON(response);

                if(data.status == 1){

                    alert(data.message);

                    setTimeout(function(){
                        location.reload();
                    }, 1000);
                }
            });
        }
    });



    // delete the record
    jQuery(".cust-plugin-delete").on("click", function () {
        event.preventDefault(); 
        var conf = confirm("Are you sure want to delete?");
        if (conf) { // true
            var dataid = jQuery(this).attr("data-id");
            var postdata = "action=admin_ajax_request&param=delete_commission&id=" + dataid;
            //var postdata = jQuery("#frmAddPlaylists").serialize() + "&action=admin_ajax_request&param=save_playlist";
            jQuery.post(ajaxurl, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                if (data.status == 1) {
                    jQuery("#commission-table-list").html(data.template);
                    alert(data.message);
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                }else{
                    alert(data.msg);
                }
            });
       }
   });


//end shailesh 

});